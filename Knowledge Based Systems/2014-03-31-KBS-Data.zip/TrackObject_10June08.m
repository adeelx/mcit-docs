%% 28 Aug 2013
close all
% if ~exist('files') || length(files)==0
%     files = dir('C:\\temp\\Cofriend\\S63-A320-2')
% end
%clear all;
sName='\PhD_Work\VideoIimages\Videos\Test_trafic.avi';
% sName='R:\trafic_videoandFrames\TrainVdo\Training_trafic.avi';
%d = imread(sprintf('C:\\temp\\Cofriend\\S63-A320-2\\%d.jpg',1));
fInfo=aviinfo(sName);
d=aviread(sName,1);
h=mexCvBSLib(d.cdata);%Initialize
%h=mexCvBSLib(d);%Initialize
 mexCvBSLib(d.cdata,h,[0.01 4*4 1 0.5]);%set parameters
%mexCvBSLib(d,h,[0.01 4*4 1 0.5]);%set parameters
figure(1)
thresh=40;% we can set different threshold values
Idstack=[];
 for i=1:1000%fInfo.NumFrames
     i
%for i=1:10:length(files)-3
         d=aviread(sName,i);   % Can be changed starting frame of video
    %d = imread(sprintf('C:\\temp\\Cofriend\\S63-A320-2\\%d.jpg',i));
    %subplot(1,2,1);imshow(d);
      imMask=mexCvBSLib(d.cdata,h);
    %imMask=mexCvBSLib(d,h);
    se = strel('line',7,20);    se1 = strel('line',2,5);
    %     imMask=imdilate(imMask,se);
    %     imMask=imerode(imMask,se1);
    %     imshow(imMask);t
    %     imMask=imfill(imMask,'holes');
    %     im11=im2bw(im1);im22=im2bw(im2);im33=im2bw(im3);
    %     im11=bwareaopen(im11,2);im22=bwareaopen(im22,2);im33=bwareaopen(im33,2);
    %     im1=im1.*uint8(im11);    im2=im2.*uint8(im22);    im3=im3.*uint8(im33);
    imMask(find(imMask~=255))=0;imMask(find(imMask==255))=1;
    imMask=bwareaopen(imMask,5);
    imMask=imdilate(imMask,se);
    %     imMask=imerode(imMask,se1);
    imMask=imfill(imMask,4,'holes');
        im1=d.cdata(:,:,1);im2=d.cdata(:,:,2);im3=d.cdata(:,:,3);
%    im1=d(:,:,1);im2=d(:,:,2);im3=d(:,:,3);
    im1(find(imMask~=1))=0;im2(find(imMask~=1))=0;im3(find(imMask~=1))=0;
    newim(:,:,1)=im1; newim(:,:,2)=im2;newim(:,:,3)=im3;
    imshow(newim);pause(.001);
    
    %for 4,8 ... connected component
    [L,Num]=bwlabeln(newim,8);
    frrect=[];
    center=[];
    rc_id=0;
    if i >40
        for j=1:Num

            % finding rectangle coordinates of moving objects
            [r,c]=find(L==j);
            if abs(max(c)-min(c)) >17 && abs(max(r)-min(r)) >17
                rc_id=rc_id+1;
                rec=[min(c) min(r) abs(max(c)-min(c)) abs(max(r)-min(r))];
                if rec(1)< 288 && rec(2) < 352
                    rectangle('position',rec,'EdgeColor','r');
                    if i ==41
                        text(rec(1)+rec(3)/2,rec(2)+rec(4)/2,num2str(rc_id),'FontSize',18,'color','g');
                        Center = [rec(1)+rec(3)/2,rec(2)+rec(4)/2];
                    end
                    
                    frrect=[frrect;rec];
%                     %Save output video in images form
%                     saveas(gcf, sprintf('C:\\temp\\Presentation journal club and 31 Oct\\ForgrndImgs\\motion_seg%d.jpg',i), 'jpg')
               
                end
            end
        end
    end
    pause(.001);
    newfrect=[];
    if i > 41
        for rcno=1:size(frrect,1)
            %----------------------------------------------
            %             if (prevfrect(:,1:end-1))=0
            %                continue
            %skip that frame
            %               zeros(frrect(rcno,:));
            %               prevfrect(:,1:end-1)=0;
            %             else

            [dmin,indmin]=min(sum(abs(prevfrect(:,1:end-1)-repmat(frrect(rcno,:),size(prevfrect,1),1)),2));
            %             end


            %---------------------------------------------------
            if dmin < thresh
                text(frrect(rcno,1)+frrect(rcno,3)/2,frrect(rcno,2)+frrect(rcno,4)/2,num2str(prevfrect(indmin,end)),'FontSize',18,'color','g');
                newfrect=[newfrect;[frrect(rcno,:) prevfrect(indmin,end)]];
                Idstack=[Idstack prevfrect(:,end)'];
                Idstack=unique(Idstack);
                pause(.001);
            elseif dmin >= thresh
                newid=max(Idstack)+1;
                text(frrect(rcno,1)+frrect(rcno,3)/2,frrect(rcno,2)+frrect(rcno,4)/2,num2str(newid),'FontSize',18,'color','g');
                newfrect=[newfrect;[frrect(rcno,:) newid]];
                pause(.001);
            %Save output video in images form
%                    saveas(gcf, sprintf('C:\\temp\\Presentation journal club and 31 Oct\\ForgrndImgsNew\\%d.jpg',i), 'jpg')
            end
                    
        end
                
    end
    if i==41
        prevfrect=[frrect [1:size(frrect,1)]'];
    elseif i > 41 && size(newfrect,1)~=0
        prevfrect=newfrect;
        %% Give path Name
%         fid =fopen('C:\Users\Dr. Najeed A Khan\Desktop\Traffic_test\Trafic_09 April13.txt','a');
        
fid =fopen('\PhD_Work\MatCode\CvBSLib\Trafic_31Mar14.txt','a');
for prnno=1:size(prevfrect,1)
             fprintf(fid,'\n %d %s %d %d %d %d %d',i,'0',prevfrect(prnno,5),prevfrect(prnno,1),prevfrect(prnno,2),prevfrect(prnno,3),prevfrect(prnno,4));
        end
        fclose(fid);
    
    end
    
 end
mexCvBSLib(h);%Release memory



 

