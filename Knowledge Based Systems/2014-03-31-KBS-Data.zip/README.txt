%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UNCALIBRATED STEREO PAIR RECTIFICATION %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Author Lorenzo Sorgi
% Virtual Reality Lab
% CIRA, the Italian Aerospace Research Centre

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% USAGE:
% [H1,H2,im1t,im2t]= unc_rectify(P1,P2, im1,im2)

% INPUT:
% P1 & P2: 2 x N matrices collecting the correspondent points coordinates
% Pi= [xi1 xi2 ... xiN;
%      yi1 yi2 ... yiN]
% im1,im2: stereo images

% OUTPUT:
% H1, H2: are the rectifying homographies
% im1t, im2t: rectified images